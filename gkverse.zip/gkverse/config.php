<?php

$conn = mysqli_connect('localhost','root','','gkverse') or die('connection failed');

?>