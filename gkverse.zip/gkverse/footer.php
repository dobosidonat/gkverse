<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>Gyors elérés</h3>
         <a href="home.php">Főoldal</a>
         <a href="about.php">Rólunk</a>
         <a href="shop.php">Termékeink</a>
         <a href="contact.php">Kapcsolatfelvétel</a>
      </div>

      <div class="box">
         <h3>Extra linkek</h3>
         <a href="login.php">Bejelentkezés</a>
         <a href="register.php">Regsiztráció</a>
         <a href="cart.php">Kosár</a>
         <a href="orders.php">Rendelései</a>
      </div>

      <div class="box">
         <h3>Elérhetőségeink</h3>
         <p> <i class="fas fa-phone"></i> 06301234567 </p>
         <p> <i class="fas fa-phone"></i> 06307654321 </p>
         <p> <i class="fas fa-envelope"></i> gkverse@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> 8000, Székesfehérvár </p>
      </div>

      <div class="box">
         <h3>Kövessen minket</h3>
         <a href="#"> <i class="fab fa-facebook-f"></i> Facebook </a>
         <a href="#"> <i class="fab fa-twitter"></i> Twitter </a>
         <a href="#"> <i class="fab fa-instagram"></i> Instagram </a>
      </div>

   </div>

   <p class="credit"> &copy; copyright  @ <?php echo date('Y'); ?> by <span>Dobosi Donát Levente</span> </p>

</section>